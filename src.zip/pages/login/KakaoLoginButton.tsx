import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { Button } from "@/components/ui/button";

const KakaoLoginButton: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [searchParams] = useSearchParams();

  // URL 파라미터에서 토큰 확인 (OAuth2 콜백 후)
  useEffect(() => {
    const token = searchParams.get('token');
    if (token) {
      console.log("OAuth2 콜백으로부터 토큰 받음:", token);
      // AuthContext를 통해 로그인 처리
      login(token, token);
      console.log("카카오 OAuth2 로그인 완료");
      navigate("/");
    }
  }, [searchParams, login, navigate]);

  const handleLogin = async () => {
    console.log("카카오 OAuth2 로그인 시작...");
    setIsLoading(true);

    try {
      // 카카오 OAuth2 인증 URL 생성 - 수동으로 URL 구성
      const clientId = '0eaeed688e2125753c1a0ebf4df023be';
      const redirectUri = encodeURIComponent('http://localhost:8085/api/user/v1/auth/kakao/callback');
      const scope = encodeURIComponent('profile_nickname,account_email');
      
      const kakaoAuthUrl = `https://kauth.kakao.com/oauth/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}`;
      
      console.log("카카오 OAuth2 인증 URL:", kakaoAuthUrl);
      console.log("리다이렉트 URI (인코딩 전):", 'http://localhost:8085/api/user/v1/auth/kakao/callback');
      console.log("리다이렉트 URI (인코딩 후):", redirectUri);
      
      // URL이 올바른지 확인 (인코딩된 상태에서도 체크)
      if (!kakaoAuthUrl.includes('/callback') && !kakaoAuthUrl.includes('%2Fcallback')) {
        console.error("URL에 /callback이 포함되지 않았습니다!");
        alert("URL 생성에 문제가 있습니다. 개발자에게 문의하세요.");
        setIsLoading(false);
        return;
      }
      
      console.log("URL 검증 통과, 카카오 OAuth2 페이지로 리다이렉트");
      
      // 카카오 OAuth2 인증 페이지로 리다이렉트
      window.location.href = kakaoAuthUrl;
    } catch (error) {
      console.error("카카오 OAuth2 로그인 시작 실패:", error);
      alert("카카오 로그인에 실패했습니다. 다시 시도해주세요.");
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full">
      <Button 
        type="button" 
        variant="outline" 
        className="w-full"
        onClick={handleLogin}
        disabled={isLoading}
      >
        {isLoading ? "로그인 중..." : "Kakao로 로그인"}
      </Button>
    </div>
  );
};

export default KakaoLoginButton;
